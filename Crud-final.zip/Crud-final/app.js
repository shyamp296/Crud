const express = require('express')

const bodyParser = require('body-parser')
const path = require('path')

const app = express()
let User = []

app.set('view engine', 'ejs')
app.set('views', 'views')

app.use(bodyParser.urlencoded({ extended: false }))

app.use(express.static(path.join(__dirname, 'public')))



app.get('/', (req, res, next) => {
    res.render('form', { pageTitle: 'Add-User' })
})

app.get('/users', (req, res, next) => {
    res.render('output', {
        pageTitle: 'Users',
        user: User

    })
})

app.post('/add-user', (req, res, next) => {
    User.push(req.body)
    res.render('output', {
        pageTitle: 'Users',
        user: User
    })
})

app.post('/delete/:id', (req, res) => {
    let id = req.params.id
    User.splice(id, 1)
    res.redirect('/users')

})

app.get('/update/:id', (req, res) => {
    let index = req.params.id
    var date = User[index].dte
    res.render('edit', {
        pageTitle: 'Update',
        User: User[index],
        index: index,
        date: date,
        
    })


});

app.post("/update-user", (req, res, next) => {
    let index = Number(req.body.id)
    User.splice(index, 1, req.body)
    res.render('output', {
        pageTitle: 'Users',
        user: User
    })
})

app.listen(4000)
