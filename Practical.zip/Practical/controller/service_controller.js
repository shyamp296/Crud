const service = require('../model/service_model');

exports.serviceform = ((req, res, next) => {
    res.render('addservice', { pageTitle: 'Add-Service' })
})

exports.addService = (req, res, next) => {
    const id = req.body.id
    const name = req.body.name
    const pdte = req.body.pdte
    const ddte = req.body.ddte
    const vno = req.body.vno
    const location = req.body.location
    const sprice = req.body.sprice
    const aprice = req.body.aprice
    console.log(name);
    service.create({
        id: id,
        name: name,
        Pickup_date: pdte,
        vehicle_no: vno,
        Drop_date: ddte,
        location: location,
        service_Price: sprice,
        Payeble_amount: aprice,

    }).then(result => {
        console.log(result);
        res.redirect('/Services')
    }).catch(err => {
        console.log(err)
    })
}

exports.showServices = (req, res, next) => {
    service.findAll().then(customer => {
        res.render('Services', {
            pageTitle: 'Service',
            user: customer
        })
    })
}

exports.deleteservice = (req, res) => {
    var id = req.body.id
    service.findByPk(id).then(services => {
        return services.destroy()
    }
    ).then(() => {
        res.redirect('/Services')
    })
}
exports.updateservice = (req, res) => {
    var id = req.body.id
    service.findByPk(id).then(customer => {
        res.render('editservice', {
            pageTitle: 'Update',
            User: customer,
        })
    })
}

exports.update = (req, res, next) => {
    const id = req.body.id
    const name = req.body.name
    const pdte = req.body.pdte
    const ddte = req.body.ddte
    const vno = req.body.vno
    const location = req.body.location
    const sprice = req.body.sprice
    const aprice = req.body.aprice

    service.findByPk(id).then(user => {

        user.name = name
        user.Pickup_date = pdte
        user.vehicle_no = vno
        user.Drop_date = ddte
        user.location = location
        user.service_Price = sprice
        user.Payeble_amount = aprice

        return user.save()
    }).then(result => {
        console.log(result);
        res.redirect('/Services')
    })


}

