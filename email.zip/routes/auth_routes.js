const express = require('express')

const router = express.Router()

const authController = require('../controller/auth_controller')

const auth  = require('../middleware/auth')


router.get('/sign-In', authController.getlogin)
router.post('/sign-In', authController.signIn)
router.get('/registration', authController.getregister)
router.post('/registration', authController.addUser)
router.get('/sign-Out', auth, authController.signOut)
router.get('/forget-password',  authController.getforgetPassword)
router.post('/forget-password',  authController.postforgetPasword)
router.get('/reset-password/:id',  authController.getresetPassword)
router.post('/reset-password',  authController.postresetPassword)



module.exports = router