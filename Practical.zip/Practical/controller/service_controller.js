const Customer = require('../model/customer_model');
const service = require('../model/service_model');

exports.serviceform = ((req, res, next) => {
    Customer.findAll({attributes : ['id','name']}).then((customer) => {
        console.log(customer);
    res.render('addservice', { pageTitle: 'Add-Service' , customer})
    })
})

exports.addService = (req, res, next) => {
    const id = req.body.id
    const name = req.body.name
    const pdte = req.body.pdte
    const ddte = req.body.ddte
    const vno = req.body.vno
    const location = req.body.location
    const slocation = req.body.slocation
    const sprice = req.body.sprice
    const aprice = req.body.aprice
    const cid = req.body.customerId

    service.create({
        id: id,
        name: name,
        Pickup_date: pdte,
        vehicle_no: vno,
        Drop_date: ddte,
        location: location,
        service_Price: sprice,
        Payeble_amount: aprice,
        customerId : cid,
        service_location : slocation,
        Sactive : 1

    }).then(result => {
        console.log(result);
        res.redirect('/Services')
    }).catch(err => {
        console.log(err)
    })
}

exports.showServices = (req, res, next) => {
    service.findAll({include : Customer}).then(services => {
        console.log(JSON.stringify(services, null, 2));
        // console.log(services);
        res.render('Services', {
            pageTitle: 'Service',
            services
            
        })
    })
}

exports.deleteservice = (req, res) => {
    var id = req.body.id
    service.findByPk(id).then(services => {
        return services.destroy()
    }
    ).then(() => {
        res.redirect('/Services')
    })
}
exports.updateservice = (req, res) => {
    var id = req.body.id
    service.findByPk(id).then(customer => {
        res.render('editservice', {
            pageTitle: 'Update',
            User: customer,
        })
    })
}

exports.update = (req, res, next) => {
    const id = req.body.id
    const pdte = req.body.pdte
    const ddte = req.body.ddte
    const vno = req.body.vno
    const location = req.body.location
    const slocation = req.body.slocation
    const sprice = req.body.sprice
    const aprice = req.body.aprice
    console.log(id);

    service.findByPk(id).then(user => {


        user.Pickup_date = pdte
        user.vehicle_no = vno
        user.Drop_date = ddte
        user.location = location
        user.service_location = slocation
        user.service_Price = sprice
        user.Payeble_amount = aprice

        return user.save()
    }).then(result => {
        console.log(result);
        res.redirect('/Services')
    })


}

