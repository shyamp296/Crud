const bcrypt = require('bcrypt')
const nodemailer = require('nodemailer')
const jwt = require('jsonwebtoken')
const User = require('../models/user_model')

const SECRET_KEY = "Shyamdadhaniya"


const trasporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {

        user: 'sdpatel320@gmail.com',
        pass: 'xkqmdiatqzbrzuue'
    }
})

exports.getlogin = ((req, res, next) => {
    res.render('login', {
        pagetitle: 'Login'
    })
})

exports.getregister = ((req, res, next) => {
    res.render('registration', {
        pagetitle: 'registration'
    })
})

exports.addUser = async (req, res, next) => {
    const Username = req.body.username
    const email = req.body.email
    const Password = req.body.psw
    const country = req.body.country

    try {
        const existinguser = await User.findOne({ email: email })
        if (existinguser) {
            console.log('email is already exist');
            return res.redirect('/registration')
        }
        const existinguser3 = await User.findOne({ username: Username })
        if (existinguser3) {
            console.log('username is already exist');
            return res.redirect('/registration')
        }

        const hashedPassword = await bcrypt.hash(Password, 12)


        const user = new User({
            username: Username,
            email: email,
            Password: hashedPassword,
            Country: country
        })



        user.save().then((result) => {
            trasporter.sendMail({
                to: email,
                from: 'sdpatel320@gmail.com',
                subject: 'signup successful',
                html: '<h1>your account has been successfully create</h1>'
            })

            res.redirect('/sign-In')

        }).catch((err) => {
            console.log(err)
        });
    } catch (error) {
        console.log(error);
    }
}

exports.signIn = async (req, res, next) => {

    const username = req.body.username
    const Password = req.body.password


    try {

        const existingUser = await User.findOne({ username: username })
        if (!existingUser) {
            console.log('user not found');
            return res.redirect('/registration')
        }

        const matchpassword = await bcrypt.compare(Password, existingUser.Password)
        if (!matchpassword) {
            console.log('Password is incorrect');
            return res.redirect('/sign-In')
        }

        const token = jwt.sign({ id: existingUser._id }, SECRET_KEY)

        res.cookie('token', token, {
            httpOnly: true,
            maxAge: 4000,


        })
        res.redirect('/')


    } catch (error) {

        console.log(error);
    }
}

exports.signOut = async (req, res, next) => {

    res.clearCookie("token")
    res.redirect('/login')
}

exports.getforgetPassword = (req, res, next) => {

    res.render('forgetPassword', {
        pagetitle: 'Forget-Password'
    })
}

exports.postforgetPasword = async (req, res, next) => {

    const email = req.body.email

    const user = await User.findOne({ email: email })
    if (user) {
        console.log(user);

        // const token = jwt.sign('ftoken', token , { 
        //     maxAge : 4000,
        //     http : true
        // })
        // res.render('resetPassword',{
        //     pagetitle : 'Reset-password',
        //     user
        // })

        trasporter.sendMail({
            to: email,
            from: 'sdpatel320@gmail.com',
            subject: 'signup successful',
            html: `<p>Click <a href=http://localhost:5000/reset-password/${user._id}>here</a> to reset your password</p>`
        }).then(ress => {
            // confirm('your reset link has been sent to your mail')
            res.redirect('/sign-In')
            console.log('sent');
        })
    } else {

        res.redirect('/forget-password')
    }

}

exports.getresetPassword = (req, res, next) => {
    const id = req.params.id
    res.render('resetPassword', {
        pagetitle: 'Reset-password',
        id
    })
}


exports.postresetPassword = async (req, res, next) => {

    const id = req.body.id
    const password = req.body.psw
    
    const hashedPassword = await bcrypt.hash(password, 12)
    const user = await User.findOne({ _id: id })
    if (user) {
        user.Password = hashedPassword

        user.save().then(result => {
            res.redirect('/sign-In')
        })
    }

}


