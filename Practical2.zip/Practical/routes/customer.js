const path = require('path');

const express = require('express');

const customerController = require('../controller/customer_controller');


const router = express.Router();

router.get('/', customerController.customerform);

router.post('/add-customer',customerController.addCustomer)

router.get('/Customers',customerController.showcustomer)

router.post('/delete', customerController .deletecustomer)

router.post('/update',customerController.editcustomer)

router.post('/edit',customerController.updatecustomer)

module.exports = router;