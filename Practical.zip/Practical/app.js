const express = require('express')
const pg = require('pg')

const bodyParser = require('body-parser')
const path = require('path')

const app = express()

const sequelize = require('./util/database')


const costumerroutes = require('./routes/customer');
const serviceroutes = require('./routes/service');
const Customer = require('./model/customer_model')
const service = require('./model/service_model')

app.set('view engine', 'ejs')
app.set('views', 'views')

app.use(bodyParser.urlencoded({ extended: true }))

app.use(express.static(path.join(__dirname,'./', 'public')))

app.use(costumerroutes)
app.use(serviceroutes)

Customer.hasMany(service)
service.belongsTo(Customer)

try {
    sequelize.authenticate();
    sequelize.sync().then((result) => {
        app.listen(5000)
    })
    console.log('Connection has been established successfully.');
} catch (error) {
    console.error('Unable to connect to the database:', error);
}