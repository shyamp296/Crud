const express = require('express')

const bodyParser = require('body-parser')

const app = express()
let User = []

app.set('view engine', 'ejs')
app.set('views', 'views')

app.use(bodyParser.urlencoded({ extended: false }))


app.get('/', (req, res, next) => {
    res.render('form', { pageTitle: 'Add-User' })
})

app.get('/users', (req, res, next) => {
    res.render('output', {
        pageTitle: 'Users',
        user: User

    })
})

app.post('/add-user', (req, res, next) => {
    User.push({
        id: (User.length + 1).toString(),
        fname: req.body.fname,
        lname: req.body.lname,
        email: req.body.email,
        Password: req.body.psw,
        gender: req.body.gender

    })
    console.log(User)
    res.redirect('/users')
})

app.get('/edit/:id', (req, res) => {
    let id = req.params.id
    console.log(id)
    let newUser = User.filter(el => el.id != id)
    User = newUser

    res.render('output', {
        pageTitle: 'Users',
        user: User
    })
})

app.get('/update', (req, res) => {
    let id = req.params.id
    let data = req.body
    // let lname = req.body.lname
    // let  email =  req.body.email
    // let   Password =  req.body.psw
    // let  gender =  req.body.gender

    let index = User.findIndex(el => el.id == id)
    // console.log(index)
    console.log("data : ", data);

    // User[index = {
    //     ...User[index],
    //     data : data
    // }]
    var data1 = User[index];

    console.log(data1);

    res.render('edit', { index: index, pageTitle: 'Edit' })
});

app.post("/update-user", (req, res, next) => {



})

app.listen(4500)