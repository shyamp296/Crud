const {Sequelize} = require('sequelize')

const sequelize = new Sequelize('practicle','admin','admin',
    {
        dialect : 'postgres',
        host: 'localhost'
    }
)
module.exports = sequelize