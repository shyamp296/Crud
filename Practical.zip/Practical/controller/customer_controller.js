const customer = require('../model/customer_model');

exports.customerform = ((req, res, next) => {
    res.render('addcustomer', { pageTitle: 'Add-User' })
})

exports.addCustomer = (req, res, next) => {
    const id = req.body.id
    const name = req.body.name
    const email = req.body.email
    const psw = req.body.psw
    const pswc = req.body.pswc
    const dte = req.body.dte
    const phone = req.body.phone
    const addr = req.body.addr
    const country = req.body.country
    console.log(name);
    customer.create({
        id: id,
        name: name,
        email: email,
        password: psw,
        Confirm_password: pswc,
        date_of_birth: dte,
        phone: phone,
        address: addr,
        country: country,
        Cactive: 1
    }).then(result => {
        console.log(result);
        res.redirect('/Customers')
    }).catch(err => {
        console.log(err)
    })
}

exports.showcustomer = (req, res, next) => {
    customer.findAll().then(customer => {
        res.render('customer', {
            pageTitle: 'Customer',
            user : customer
        })
    })
}

exports.deletecustomer = (req, res) => {
    var id = req.body.id
    customer.findByPk(id).then(Customer => {
        return Customer.destroy()
    }
    ).then(() => {
        res.redirect('/Customers')
    })
}
exports.updatecustomer = (req, res) => {
    var id = req.body.id
    customer.findByPk(id).then(customer => {
        res.render('editcustomer', {
            pageTitle: 'Update',
            User: customer,
        })
    })
}

exports.update = (req, res, next) => {
    const id = req.body.id
    const name = req.body.name
    const email = req.body.email
    const psw = req.body.psw
    const pswc = req.body.pswc
    const dte = req.body.dte
    const phone = req.body.phone
    const addr = req.body.addr
    const country = req.body.country
    
    customer.findByPk(id).then(user => {

        user.name = name
        user.email = email
        user.password= psw
        user.Confirm_password = pswc
        user.date_of_birth = dte
        user.phone = phone
        user.address = addr
        user.country = country

        return user.save()
    }).then(result => {
        console.log(result);
        res.redirect('/customers')
    })


}
