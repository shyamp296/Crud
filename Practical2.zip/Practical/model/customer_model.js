const Sequelize = require('sequelize')

const sequelize = require('../util/database')

const Customer = sequelize.define('customer', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    email: {
        type: Sequelize.STRING,
        allowNull: false
    },
    phone: {
        type: Sequelize.BIGINT
    },
    password: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Confirm_password: {
        type: Sequelize.STRING,
    },
    date_of_birth: {
        type: Sequelize.DATEONLY,

    },
  
    country: {
        type: Sequelize.STRING
    },
    address: {
        type: Sequelize.TEXT
    },
    



},
{
    sequelize,
    paranoid : true,
    deletedAt: 'soft_delete'
})

module.exports = Customer