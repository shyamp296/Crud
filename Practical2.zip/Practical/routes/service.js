const path = require('path');

const express = require('express');

const serviceController = require('../controller/service_controller');


const router = express.Router();
router.get('/s',serviceController.serviceform)

router.post('/add-service', serviceController.addService)

router.get('/Services', serviceController.showServices)

router.post('/sdelete', serviceController.deleteservice)

router.post('/supdate', serviceController.updateservice)

router.post('/sedit', serviceController.update)

module.exports = router;