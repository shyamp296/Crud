const path = require('path')
const User = require('../models/user_model')

exports.dashbord = (async(req ,res) => {

    const users = await User.findOne({_id : id})
    res.render('home',{
        pagetitle : 'Home',
        user : users
    })
    
})