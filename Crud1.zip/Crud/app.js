const express = require('express')

const bodyParser = require('body-parser')
const path = require('path')

const app = express()
let User = []

app.set('view engine', 'ejs')
app.set('views', 'views')

app.use(bodyParser.urlencoded({ extended: false }))



app.get('/', (req, res, next) => {
    res.render('form', { pageTitle: 'Add-User' })
})

app.get('/users', (req, res, next) => {
    res.render('output', {
        pageTitle: 'Users',
        user: User

    })
})

app.post('/add-user', (req, res, next) => {
    User.push({
        id: (User.length).toString(),
        fname: req.body.fname,
        lname: req.body.lname,
        email: req.body.email,
        Password: req.body.psw,
        date:req.body.date,
        add : req.body.addr

    })
    console.log(User)
    res.redirect('/users')
})

app.get('/delete/:id', (req, res) => {
    let id = req.params.id
    User.splice(id,1)
    res.redirect('/users')
    
})

app.get('/update/:id', (req, res) => {
    let index = req.params.id
    
    console.log(index)
    res.render('edit',{ pageTitle : 'Update',
        User : User[index],
        index : index
    })


});

app.post("/update-user", (req, res, next) => {
    let index = Number(req.body.id)
    User.splice(index , 1 ,req.body)
    res.redirect('/users')
})

app.listen(4500)