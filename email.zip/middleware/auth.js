const jwt = require('jsonwebtoken')

const SECRET_KEY = "Shyamdadhaniya"

const auth = (res, req, next) => {


    try {

        const token = res.cookies.token
        if(token){
        const User = jwt.verify(token, SECRET_KEY)
        
        
        req.User = User
        id = User.id
        next()

        }else { 
            return req.redirect('/sign-In')
        }
    } catch (error) {
        
        console.log(error);
    }
}

module.exports = auth