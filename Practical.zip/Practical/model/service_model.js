const Sequelize = require('sequelize')

const sequelize = require('../util/database')

const service = sequelize.define('service', {
    id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    vehicle_no : {
        type: Sequelize.STRING,
        allowNull: false
    },
    Pickup_date: {
        type: Sequelize.DATEONLY,

    },
    Drop_date : {
        type: Sequelize.DATEONLY,

    },
    service_location: {
        type: Sequelize.TEXT
    },

    location: {
        type: Sequelize.TEXT
    },
    service_Price : {
        type: Sequelize.INTEGER
    },
    Payeble_amount : {
        type: Sequelize.INTEGER
    },
  



})

module.exports = service